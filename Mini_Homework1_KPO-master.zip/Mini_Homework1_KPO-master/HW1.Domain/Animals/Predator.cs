using HW1.Domain.Animals;

namespace HW1.Domain;

public abstract class Predator : Animal
{
}
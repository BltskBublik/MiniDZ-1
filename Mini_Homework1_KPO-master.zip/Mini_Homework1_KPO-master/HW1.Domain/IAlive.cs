﻿namespace HW1.Domain;

public interface IAlive
{
    int Food { get; set; }
}

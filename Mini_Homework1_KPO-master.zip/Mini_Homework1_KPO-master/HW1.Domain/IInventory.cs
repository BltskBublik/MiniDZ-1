namespace HW1.Domain;

public interface IInventory
{
    int Number { get; set; }
}
namespace HW1.Domain;

public interface IInventoryNumberGenerator
{
    int GetNextInventoryNumber();
}
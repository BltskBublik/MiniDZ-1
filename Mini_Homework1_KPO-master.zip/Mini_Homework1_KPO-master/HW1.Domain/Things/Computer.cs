namespace HW1.Domain.Things;

public class Computer : Thing
{
    public Computer(string name)
    {
        Name = name;
    }
}
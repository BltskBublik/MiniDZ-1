namespace HW1.Domain.Things;

public class Table : Thing
{
    public Table(string name)
    {
        Name = name;
    }
}